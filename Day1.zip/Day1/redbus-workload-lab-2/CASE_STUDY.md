# redBus Use Case — Workload Modelling Pain Points & Root-Cause Analysis
### Module 2: Performance-Test Methodologies and Workload Modelling

## Scenario

redBus is running a flash sale. A performance tester is asked to validate
the **seat-hold → payment** journey ahead of the sale. This lab's backend
([main.py](main.py)) has three deliberate issues that only surface through
*how* the test is modelled, not through functional testing.

## Customer-facing pain points

| # | Complaint | Where it shows up |
|---|---|---|
| 1 | "It said my seat was already taken, but it was free — I could book it a second later" | Frequent, spurious 409 "seat already held" errors during the sale |
| 2 | "The load test showed 0% errors, but real users saw payments fail during the sale" | Test report vs. production incident contradict each other |
| 3 | "My payment went through on someone else's booking reference" | Payment applied to the wrong hold/session |
| 4 | "Everything was fine for the first 20 minutes, then payments started timing out" | Only shows up on long-running sale windows, not short smoke tests |

## Root-cause identification, mapped to Module 2 topics

### 1. Test-data design, reuse, and uniqueness → pain point #1

**Captured evidence** (`closed_bad_stats.csv`, 20 virtual users, shared
`seat_id=S1` for every VU):

| Endpoint | Requests | Failures | Failure rate |
|---|---|---|---|
| `/api/booking/hold` | 250 | 239 | **95.6%** |
| `/api/payment/charge` | 11 | 0 | 0% |

Compare to the same test with unique seats per VU
(`closed_good_stats.csv`):

| Endpoint | Requests | Failures | Failure rate |
|---|---|---|---|
| `/api/booking/hold` | 310 | 0 | **0%** |
| `/api/payment/charge` | 303 | 0 | 0% |

**Root cause:** the test script reused one seat_id (`test_data/seats_bad_shared.csv`)
across all 20 virtual users instead of parameterizing test data
(`test_data/seats_good.csv`). Every VU after the first collided on the
same seat and got a legitimate 409 from the app — a **test artifact**,
not a product defect. This is exactly the kind of false signal Module 2's
"test-data design, reuse, uniqueness and cleanup" topic exists to prevent:
without parameterized, unique test data, load-test failures are
uninterpretable — you can't tell a real concurrency bug from a test-data
collision.

### 2. Closed vs. open workload model → pain point #2

**Captured evidence:**

| Model | Load | Success rate | P50 | P95 | P99 |
|---|---|---|---|---|---|
| Closed (Locust, 20 VUs looping) | self-throttling | 100% | 8ms (hold) / 290ms (pay) | 360ms / 390ms | 460ms / 470ms |
| Open (fixed arrival, 5 req/s) | 100 journeys/20s | 100% | 394ms | 418ms | 422ms |
| Open (fixed arrival, 15 req/s) | 300 journeys/20s | **90.0%** | **3,487ms** | 6,004ms | 6,279ms |

**Root cause:** the payment gateway simulator has a fixed capacity of 5
concurrent transactions (`GATEWAY_CAPACITY = 5` in `main.py`). Under the
**closed model**, each of the 20 VUs waits for its own request to finish
before sending the next one — so the moment the gateway gets slow, VUs
back off automatically and the offered load self-limits. The closed-model
run never generates enough simultaneous demand to expose the gateway's
capacity ceiling, and reports a clean 0% error rate.

The **open model** fires new journeys at a fixed rate regardless of how
long previous ones take — exactly how real users behave during a flash
sale (they don't wait for your server to recover before the next person
clicks "Pay"). At 15 req/s the offered load exceeds the gateway's
sustainable throughput (5 capacity ÷ ~0.3s per transaction ≈ 16-17 req/s
theoretical ceiling once queuing is added), so requests queue behind the
semaphore, some exceed the 3s timeout, and **10% fail with 503s while
P50 latency balloons to 3.5s.**

This is the single most important lesson of Module 2: a closed-model
load test can report a clean bill of health on a system that will fail
in production, because production arrivals are open, not closed.

### 3. Auth-token correlation → pain point #3

`closed_workload_locustfile.py` has a `BAD_TOKEN=1` mode that skips
per-VU login and reuses one static token for every virtual user —
exactly what happens when a script hardcodes a captured token instead of
extracting and correlating it from each VU's own `/api/auth/login`
response. Run it and every VU can hold/pay against *any* other VU's
booking, because the server can't distinguish sessions. In production
this exact test-script shortcut would hide a real authorization bug
(the app correctly checks `hold["token"] != token` in `main.py`, but the
test never generates more than one token to check against).

### 4. Soak/endurance testing → pain point #4

`main.py`'s `PROCESSED_LOG` is appended on every successful payment and
never trimmed (`backlog_penalty = len(PROCESSED_LOG) * 0.0005`). A short
load test won't accumulate enough volume for this to matter. Run the
**open-model generator for a long duration** (e.g. `--duration 1800`)
and per-transaction latency creeps up over the run purely as a function
of total volume processed — a resource-leak pattern that only an
endurance/soak test (not a 5-minute load test) will catch.

## How the hands-on lab reproduces this

1. Start `main.py` and confirm the manual UI flow (login → hold → pay) works.
2. Run `closed_workload_locustfile.py` with `SEAT_FILE=test_data/seats_good.csv`
   — clean baseline.
3. Re-run with `SEAT_FILE=test_data/seats_bad_shared.csv` — reproduce the
   95%+ hold failure rate and discuss: is this a defect or a test-data bug?
4. Run `open_workload_generator.py --rps 5` then `--rps 15` — reproduce the
   closed-vs-open divergence and connect it to Little's Law and the
   gateway's fixed capacity.
5. Re-run the closed script with `BAD_TOKEN=1` — observe cross-session
   payment leakage and discuss correlation.
6. (Optional, time permitting) run the open generator for 20-30 minutes
   and chart latency over time to see the soak-only leak.
7. Fill in `WORKLOAD_STRATEGY_TEMPLATE.md` for redBus's flash-sale
   requirement using the numbers captured above.
