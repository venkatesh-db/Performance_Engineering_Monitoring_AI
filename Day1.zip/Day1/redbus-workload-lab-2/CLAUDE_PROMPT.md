# Prompt to give Claude for this lab

```
I ran two workload models against a redBus-style seat-hold + payment API
(FastAPI demo, payment gateway simulator with fixed capacity=5 concurrent
transactions). Here is what I captured:

CLOSED model (Locust, 20 virtual users looping, unique test data):
- /api/booking/hold: 310 reqs, 0 failures
- /api/payment/charge: 303 reqs, 0 failures, P50=290ms, P95=390ms, P99=470ms

CLOSED model with SHARED test data (same seat_id for all 20 VUs):
- /api/booking/hold: 250 reqs, 239 failures (95.6%), all 409 Conflict

OPEN model (fixed arrival rate, independent of response time):
- 5 req/s for 20s: 100 journeys, 100% success, P50=394ms, P99=422ms
- 15 req/s for 20s: 300 journeys, 90% success, P50=3,487ms, P99=6,279ms

Acting as a performance tester presenting root-cause findings to a
stakeholder, do the following:
1. Explain why the closed-model run reported 0% errors while the open
   model at 15 req/s reported 10% failures on the exact same backend —
   reference Little's Law and how each model treats arrival rate.
2. Separate the "shared test data" failures from a real product defect —
   what evidence in the data tells you this is a test-data bug, not an
   application bug?
3. State the effective throughput ceiling of the payment gateway implied
   by the data, and what arrival rate redBus's real flash-sale traffic
   would need to stay under to avoid the failure mode seen at 15 req/s.
4. Recommend which workload model (open vs closed) should be the primary
   go/no-go gate for this flash-sale launch, and why the other one is
   still worth running.

Be specific and cite the numbers I gave you.
```

## Notes
- Attach `main.py`, `CASE_STUDY.md`, and the raw CSVs
  (`closed_good_stats.csv`, `closed_bad_stats.csv`) for Claude to reason
  from real evidence.
- If you also run the `BAD_TOKEN=1` or long soak scenarios, paste those
  results and ask Claude to fold them into the same root-cause writeup.
