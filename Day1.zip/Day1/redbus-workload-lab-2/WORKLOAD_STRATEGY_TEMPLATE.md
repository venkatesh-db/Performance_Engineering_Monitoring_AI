# Performance-Test Strategy Template

Fill this in per business requirement before writing a single test script.

## 1. Business requirement -> workload model

- **Business statement:** _(e.g. "system must support 10,000 seat bookings/hour during a flash sale")_
- **Peak arrival rate (λ):** requirement ÷ time window, e.g. 10,000/hour = **2.78 req/s** sustained, plus a spike multiplier for the first 5 minutes of a sale (commonly 3-5x baseline).
- **Business-transaction mix:** % of traffic per journey, from production analytics or estimate.
  | Transaction | % of mix | Notes |
  |---|---|---|
  | Search | | typically the largest share, cheap per request |
  | Seat hold | | must be unique per concurrent user (see test-data section) |
  | Payment | | usually gated by a downstream PSP capacity limit |
- **Concurrency (L) via Little's Law:** `L = λ × W`. Estimate W (expected response time) from an SLA or a prior baseline, then compute the concurrent users needed to sustain λ.

## 2. Workload model: open vs closed

- Which model matches how real users arrive? (Almost always **open** — user arrivals don't wait for your server.)
- Which model does your tool default to? (Most tools, including Locust, default to **closed** — fixed VU pool looping.)
- Decision: __________ (state why, and what risk you accept by not testing the other model.)

## 3. Test types to run (tick and size each)

| Type | Purpose | Duration | Load profile |
|---|---|---|---|
| Baseline | Establish reference point at low concurrency | | |
| Load | Validate expected peak | | |
| Stress | Find the breaking point beyond expected peak | | |
| Spike | Sudden jump to N x baseline, then back down | | |
| Soak/Endurance | Catch leaks/degradation over hours | | |
| Volume/Capacity | Large data volumes (e.g. catalog size) | | |

## 4. Concurrency, arrival rate, pacing

- Ramp-up: how fast do virtual users/arrivals reach target? (avoid a thundering-herd start that isn't realistic)
- Think time: per transaction, based on real user behavior, not zero.
- Pacing: fixed iteration time vs. fixed arrival rate — must match the workload model decision above.

## 5. Test-data design

- Fields needing uniqueness per virtual user/iteration: __________ (e.g. seat_id, coupon_code, phone_number)
- Data source: pre-generated pool / on-the-fly generation / production-like synthetic data
- Reuse policy: can data be reused across iterations, or must it be single-use?
- Cleanup: how is test data (and its side effects — bookings, holds, DB rows) removed after the run?

## 6. Auth-token handling

- Token acquisition: per-VU login vs. shared/static token
- Correlation: is the token extracted from the login response and threaded through every subsequent request per VU?
- Expiry: does the script re-authenticate if the token expires mid-run?

## 7. Environment-readiness / entry criteria

- [ ] Environment matches production topology (or documented deltas)
- [ ] Test data seeded and volume matches production scale
- [ ] Downstream dependencies (PSP, third-party APIs) stubbed/sized appropriately and stated in the report
- [ ] Monitoring/APM enabled on all tiers before the run starts
- [ ] Baseline run completed and reviewed before scaling up

## 8. Success criteria

| Metric | Target | Source |
|---|---|---|
| P95 latency | | SLA / NFR doc |
| P99 latency | | SLA / NFR doc |
| Throughput | | business requirement |
| Error rate | | SLA / NFR doc |
| Resource usage (CPU/mem/connections) | | capacity plan |
