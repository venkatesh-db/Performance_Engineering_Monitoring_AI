"""
CLOSED workload model: a fixed pool of virtual users, each one looping
(login once, then hold-seat -> pay, with think time) as fast as the
server lets it. If the server slows down, each VU just takes longer per
iteration -- the arrival rate self-throttles. This is Locust's default
behavior and is exactly why a closed-model test can under-report real
production risk: it never generates more concurrent demand than the
number of VUs you started, no matter how slow the server gets.

Env vars for the lab exercises:
  SEAT_FILE   path to a CSV of seat_ids to parameterize test data.
              Try test_data/seats_good.csv (unique per VU) vs
              test_data/seats_bad_shared.csv (same seat reused) to see
              the difference between a real defect and a test-data bug.
  BAD_TOKEN   if set to "1", every VU shares one static token instead of
              logging in individually -- demonstrates an auth-correlation
              bug hiding session isolation problems.

Run:
  locust -f closed_workload_locustfile.py --host=http://127.0.0.1:8000
"""
import itertools
import os
import csv
from pathlib import Path

from locust import HttpUser, task, between, events

SEAT_FILE = os.environ.get("SEAT_FILE", "test_data/seats_good.csv")
BAD_TOKEN = os.environ.get("BAD_TOKEN") == "1"

_seat_path = Path(__file__).parent / SEAT_FILE
with open(_seat_path) as f:
    SEATS = [row["seat_id"] for row in csv.DictReader(f)]
_seat_cycle = itertools.cycle(SEATS)

_shared_token = {"value": None}


class BookingUser(HttpUser):
    wait_time = between(1, 2)  # think time between iterations

    def on_start(self):
        self.seat_id = next(_seat_cycle)
        if BAD_TOKEN:
            if _shared_token["value"] is None:
                r = self.client.post("/api/auth/login", json={"username": "shared-demo-user"})
                _shared_token["value"] = r.json()["token"]
            self.token = _shared_token["value"]
        else:
            r = self.client.post("/api/auth/login", json={"username": f"user-{self.seat_id}"})
            self.token = r.json()["token"]

    @task
    def hold_and_pay(self):
        headers = {"Authorization": f"Bearer {self.token}"}
        r = self.client.post("/api/booking/hold", json={"seat_id": self.seat_id}, headers=headers, name="/api/booking/hold")
        if r.status_code != 200:
            return  # seat conflict -- expected if using seats_bad_shared.csv
        hold_id = r.json()["hold_id"]
        self.client.post(
            "/api/payment/charge",
            json={"hold_id": hold_id, "amount": 650},
            headers=headers,
            name="/api/payment/charge",
        )
