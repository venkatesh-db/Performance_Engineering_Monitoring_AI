"""
redBus-style booking + payment API for Module 2 (workload modelling).

Simulates the "hold a seat -> pay" flow with three deliberate issues that
map directly to the module's topics:

1. Seat-hold uniqueness: holding a seat that's already held (by another
   *test user*, not a real conflict) returns 409. This exists so a badly
   designed test (reusing one seat_id across all virtual users instead of
   parameterizing test data) produces a wall of 409s that looks like a
   product bug but is actually a test-data design flaw.

2. Auth-token correlation: every call must carry a per-user bearer token
   from /api/auth/login. A test script that hardcodes one static token
   for all virtual users will silently let every "user" pay for the same
   session -- a correlation bug that a closed workload test can hide.

3. Payment gateway capacity + slow leak: the payment gateway simulator
   has a fixed concurrency capacity (semaphore) representing a real PSP's
   throughput ceiling, and its per-call cost grows slowly with total
   volume processed (unbounded in-memory log), simulating a resource
   leak that only shows up on a long soak test, not a 5-minute load test.
"""
import threading
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

app = FastAPI(title="redBus Workload Modelling Lab")
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

# --- in-memory state -------------------------------------------------
TOKENS: dict[str, str] = {}                # token -> username
SEAT_HOLDS: dict[str, dict] = {}            # seat_id -> {token, expires_at, hold_id}
HOLDS_BY_ID: dict[str, dict] = {}           # hold_id -> {seat_id, token, paid}
HOLD_TTL_SECONDS = 60

GATEWAY_CAPACITY = 5                        # simulated PSP concurrent-txn ceiling
_gateway_semaphore = threading.Semaphore(GATEWAY_CAPACITY)
PROCESSED_LOG: list[float] = []             # BUG: never trimmed -> slow leak over a soak run
_log_lock = threading.Lock()


class LoginRequest(BaseModel):
    username: str


class HoldRequest(BaseModel):
    seat_id: str


class ChargeRequest(BaseModel):
    hold_id: str
    amount: int


def _require_token(authorization: str | None) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "missing bearer token")
    token = authorization.removeprefix("Bearer ")
    if token not in TOKENS:
        raise HTTPException(401, "invalid token")
    return token


@app.get("/")
def index():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.post("/api/auth/login")
def login(req: LoginRequest):
    token = uuid.uuid4().hex
    TOKENS[token] = req.username
    return {"token": token, "username": req.username}


@app.post("/api/booking/hold")
def hold_seat(req: HoldRequest, authorization: str | None = Header(None)):
    token = _require_token(authorization)
    now = time.time()
    existing = SEAT_HOLDS.get(req.seat_id)
    if existing and existing["expires_at"] > now and existing["token"] != token:
        raise HTTPException(409, f"seat {req.seat_id} is already held by another user")

    hold_id = uuid.uuid4().hex
    record = {"token": token, "expires_at": now + HOLD_TTL_SECONDS, "hold_id": hold_id}
    SEAT_HOLDS[req.seat_id] = record
    HOLDS_BY_ID[hold_id] = {"seat_id": req.seat_id, "token": token, "paid": False}
    return {"hold_id": hold_id, "seat_id": req.seat_id, "expires_in": HOLD_TTL_SECONDS}


@app.post("/api/payment/charge")
def charge(req: ChargeRequest, authorization: str | None = Header(None)):
    token = _require_token(authorization)
    hold = HOLDS_BY_ID.get(req.hold_id)
    if not hold:
        raise HTTPException(404, "hold not found or expired")
    if hold["token"] != token:
        raise HTTPException(403, "this hold belongs to a different session")

    acquired = _gateway_semaphore.acquire(timeout=3)
    if not acquired:
        raise HTTPException(503, "payment gateway busy, try again")
    try:
        with _log_lock:
            backlog_penalty = len(PROCESSED_LOG) * 0.0005  # grows with total volume: slow leak
        time.sleep(0.2 + backlog_penalty)
        with _log_lock:
            PROCESSED_LOG.append(time.time())
        hold["paid"] = True
        return {"hold_id": req.hold_id, "amount": req.amount, "status": "SUCCESS"}
    finally:
        _gateway_semaphore.release()


@app.get("/api/health")
def health():
    return {"status": "ok", "gateway_capacity": GATEWAY_CAPACITY, "processed": len(PROCESSED_LOG)}
