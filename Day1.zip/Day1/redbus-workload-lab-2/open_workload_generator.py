"""
OPEN workload model: new booking journeys are fired at a fixed arrival
rate (requests/sec) *regardless* of how long previous requests take to
complete. This is the key contrast with closed_workload_locustfile.py --
under an open model, if the payment gateway (capacity=5 concurrent) or
any other resource saturates, in-flight work backs up and error rate /
latency visibly climb, because nothing throttles the offered load. This
matches how real user arrivals behave in production (a flash sale
doesn't wait for your server to catch up).

Usage:
  python open_workload_generator.py --rps 8 --duration 30

Each arrival runs the full login -> hold -> pay journey with its own
unique seat_id and its own token (correct test-data / auth handling),
so any degradation you see is attributable to server capacity, not to
the test-data bugs demonstrated in the closed-model script.
"""
import argparse
import asyncio
import itertools
import time

import aiohttp

HOST = "http://127.0.0.1:8001"


async def run_journey(session: aiohttp.ClientSession, seat_id: str, results: list):
    t0 = time.time()
    try:
        r = await session.post(f"{HOST}/api/auth/login", json={"username": f"user-{seat_id}"})
        token = (await r.json())["token"]
        headers = {"Authorization": f"Bearer {token}"}

        r = await session.post(f"{HOST}/api/booking/hold", json={"seat_id": seat_id}, headers=headers)
        if r.status != 200:
            results.append({"ok": False, "status": r.status, "latency": time.time() - t0})
            return
        hold_id = (await r.json())["hold_id"]

        r = await session.post(
            f"{HOST}/api/payment/charge",
            json={"hold_id": hold_id, "amount": 650},
            headers=headers,
        )
        results.append({"ok": r.status == 200, "status": r.status, "latency": time.time() - t0})
    except Exception as e:
        results.append({"ok": False, "status": "error", "latency": time.time() - t0, "error": str(e)})


async def main(rps: float, duration: int):
    results: list = []
    seat_counter = itertools.count(1)
    interval = 1.0 / rps
    end_at = time.time() + duration

    async with aiohttp.ClientSession() as session:
        tasks = []
        next_fire = time.time()
        while time.time() < end_at:
            seat_id = f"OPEN-{next(seat_counter)}"
            tasks.append(asyncio.create_task(run_journey(session, seat_id, results)))
            next_fire += interval
            sleep_for = next_fire - time.time()
            if sleep_for > 0:
                await asyncio.sleep(sleep_for)
        await asyncio.gather(*tasks)

    total = len(results)
    ok = sum(1 for r in results if r["ok"])
    latencies = sorted(r["latency"] for r in results)

    def pct(p):
        if not latencies:
            return 0
        idx = min(int(len(latencies) * p) - 1, len(latencies) - 1)
        return latencies[max(idx, 0)] * 1000

    print(f"\nOpen-model run: target {rps} req/s for {duration}s -> offered {total} journeys")
    print(f"  success={ok} ({ok/total*100:.1f}%)  failed={total-ok} ({(total-ok)/total*100:.1f}%)")
    print(f"  latency ms: P50={pct(0.5):.0f} P95={pct(0.95):.0f} P99={pct(0.99):.0f} max={latencies[-1]*1000:.0f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rps", type=float, default=5.0, help="fixed arrival rate, requests/sec")
    ap.add_argument("--duration", type=int, default=30, help="run duration, seconds")
    args = ap.parse_args()
    asyncio.run(main(args.rps, args.duration))
