// ============================================================
// DYNAMIC / PARAMETERIZED DATA — Day 1, Module 3 demo (k6)
// ============================================================
// Builds on simple_health_check.js by showing:
//   1. Reading test data from a CSV file (SharedArray -- loaded once,
//      shared across all VUs, not re-read every iteration)
//   2. Passing a DIFFERENT customer_id per iteration through the
//      REQUEST BODY (POST /api/customers/login)
//   3. Passing dynamic values through the URL QUERY STRING
//      (GET /api/health?customer_id=...&ts=...) -- the endpoint
//      ignores them, but this is exactly the pattern you'd use against
//      a real endpoint that reads query params (e.g. GET /api/bus/{id})
//   4. Extracting a value from one response (the login token) and
//      reusing it in the next request -- basic correlation, the
//      stepping-stone to the full payment_test.js script
//
// Run it:
//   k6 run k6/dynamic_data_test.js
// ============================================================
import http from 'k6/http';
import { check, sleep } from 'k6';
import { SharedArray } from 'k6/data';

export const options = {
  vus: 5,
  duration: '10s',
};

// Loaded ONCE at init time, shared read-only across all VUs -- this is
// k6's equivalent of JMeter's "CSV Data Set Config".
const customers = new SharedArray('customers', function () {
  const csv = open('../test_data/customers.csv');
  const lines = csv.trim().split('\n').slice(1); // skip header row
  return lines.map((line) => {
    const [customer_id, amount] = line.split(',');
    return { customer_id, amount: parseInt(amount, 10) };
  });
});

export default function () {
  // Pick a different row per iteration -- dynamic, not hardcoded.
  const row = customers[Math.floor(Math.random() * customers.length)];

  // --- 1. Dynamic data through the URL query string ---
  const ts = Date.now();
  const healthRes = http.get(
    `http://127.0.0.1:8002/api/health?customer_id=${row.customer_id}&ts=${ts}`
  );
  check(healthRes, { 'health check ok': (r) => r.status === 200 });

  // --- 2. Dynamic data through the request BODY, then extract from the response ---
  const loginRes = http.post(
    'http://127.0.0.1:8002/api/customers/login',
    JSON.stringify({ customer_id: row.customer_id }),
    { headers: { 'Content-Type': 'application/json' } }
  );
  check(loginRes, { 'login returned a token': (r) => r.json('token') !== undefined });

  const token = loginRes.json('token');
  console.log(`customer=${row.customer_id} amount=${row.amount} token=${String(token).slice(0, 8)}...`);

  sleep(1);
}
