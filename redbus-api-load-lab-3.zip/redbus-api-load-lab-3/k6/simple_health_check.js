// ============================================================
// SIMPLEST POSSIBLE k6 SCRIPT — Day 1, Module 3 demo
// ============================================================
// Purpose: show participants the absolute minimum needed to load-test
// a REST API with k6, before introducing correlation, CSV data, or
// executors. One GET request, a few virtual users, one check.
//
// Run it:
//   k6 run k6/simple_health_check.js
//
// What to point out to participants while it runs:
//   - "VUs" = virtual users, each looping the default function
//   - k6 prints http_req_duration (avg/min/med/max/p90/p95) automatically
//   - checks_succeeded % tells you if the assertion passed
// ============================================================
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 5,          // 5 virtual users
  duration: '10s',  // running for 10 seconds
};

export default function () {
  const res = http.get('http://127.0.0.1:8002/api/health');

  check(res, {
    'status is 200': (r) => r.status === 200,
  });

  sleep(1); // "think time" -- pause 1s between each user's requests
}
